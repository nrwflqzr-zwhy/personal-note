package com.atguigu.java;

import java.util.Date;

/**
 * @author shkstart
 * @create 0:34
 */
public class ValueTransfer1 {
    public static void main(String[] args) {
        int m = 10;
        int n = m;

        long l1 = 10L;
        long l2 = 10L;

        Date date1 = new Date();
        Date date2 = date1;
    }
}
