package com.atguigu.java3;

import org.junit.Test;

/**
 * @author shkstart
 * @create 14:52
 */
public class InterviewTest {
    @Test
    public void test1(){
        Integer x = 128;
        int y = 128;
        System.out.println(x == y);//true
    }
}
