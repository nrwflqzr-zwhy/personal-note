package com.atguigu.java3;

/**
 * @author shkstart
 * @create  0:23
 */
public class User {
    private int id;

    @Override
    public String toString() {
        return "User{" +
                "id=" + id +
                '}';
    }
}
