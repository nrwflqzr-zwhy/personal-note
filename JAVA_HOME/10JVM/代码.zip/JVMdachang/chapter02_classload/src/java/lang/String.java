package java.lang;

/**
 * @author shkstart
 * @create 9:41
 */
//public class String {
//    byte[] value;
//}
