package com.atguigu.java;

/**
 * @author shkstart  shkstart@126.com
 * @create 2020  17:16
 */
public class ObjectTest {
    public static void main(String[] args) {
        Object obj = new Object();
    }
}
