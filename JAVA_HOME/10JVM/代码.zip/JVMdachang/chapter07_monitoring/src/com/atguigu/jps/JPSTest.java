package com.atguigu.jps;

import java.util.Scanner;

/**
 * @author shkstart
 * @create 14:57
 *
 */
public class JPSTest {
    public static void main(String[] args) {
        try {
            Thread.sleep(100000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
